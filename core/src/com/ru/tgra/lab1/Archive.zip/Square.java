package com.ru.tgra.lab1;

public class Square {
	public float x1;
	public float x2;
	public float y1;
	public float y2;
	public Square(float f, float g, float h, float i) {
		x1 = f;
		y1 = g;
		x2 = h;
		y2 = i;
	}}